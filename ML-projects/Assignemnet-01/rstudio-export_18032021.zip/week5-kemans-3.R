install.packages("NbClust")
library(NbClust)
data(iris)
str(iris)
head(iris)
iris$Species = NULL #temprorly
set.seed(26)

clusterNo=NbClust(iris,distance = 'euclidean',min.nc = 2 ,max.nc = 100,method = 'kmeans' ,index = 'all')
clusterNo

clusterNo=NbClust(iris,distance="manhattan", min.nc=2,max.nc=15,method="kmeans",index="all")

clusterNo=NbClust(iris,distance="maximum", min.nc=2,max.nc=15,method="kmeans",index="all")

#Elbow method
k = 2:10
set.seed(42)
WSS = sapply(k, function(k) {kmeans(iris[1:4], centers=k)$tot.withinss})
plot(k, WSS, type="l", xlab= "Number of k", ylab="Within sum of squares")

