## outlier test
set.seed(937573)
x <- rnorm(1000)
x[1:5] <- c(7, 10, - 5, 16, - 23) 
x
boxplot(x)  
x_out_rm <- x[!x %in% boxplot.stats(x)$out] 
length(x) - length(x_out_rm) 
boxplot(x_out_rm)

my_list <- list(list(x = 1, y = 'a'), list(x = 2, y = 'b'))

mydata <- data.frame(x, fit$cluster)
library(cluster)
clusplot(x, fit$cluster, color=TRUE, shade=TRUE,
         labels=2, lines=0)
?sample
x <- sample(c(1:11), 10, replace = T)
y <- lag(x, 1)
ds <- cbind(x, y)
ds



x.Date <- as.Date(paste(2004, rep(1:4, 4:1), sample(1:28, 10), sep = "-"))
x <- zoo(rnorm(12), x.Date)

rollmean(x, 3)
rollmax(x, 3)

exchangeGBP <- read_excel("exchangeGBP.xlsx")%>%

  janitor::clean_names() %>%
  mutate(date_in_ymd = ymd(yyyy_mm_dd))%>%

  select(-1) 
N = 10
prices <- data.frame(exchangeGBP$gbp_eur) # Dummy straight line uptrend for N periods 

print(prices)

shift <- function(x, n){
  c(x[-(seq(n))], rep(NA, n))
}

# Form the training dataframe
train <- data.frame(
  prev_close_1=prices$gbp_eur,
  prev_close_2=shift(prices$gbp_eur, 1),
  close=shift(prices$gbp_eur, 2)
)

# When shifting the columns for time lag effect, some rows will have NAs
# Let's remove NAs
train <- na.omit(train)

print(train)

nn <- neuralnet(
  formula=close ~ prev_close_1 + prev_close_2,
  data=train,
  hidden=c(1), # 1 neuron in a single hidden layer
  linear.output=TRUE # we want regression not classification
)

print(prediction(nn))
plot(nn)