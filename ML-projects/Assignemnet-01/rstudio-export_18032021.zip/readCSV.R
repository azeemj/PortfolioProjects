data <- read.csv("zxzX/diabetes.csv")
# print(data)
# print(getwd())

if(FALSE) {
  "This is a demo for multi-line comments and it should be put inside either"
}

myString <- "Hello, World!"
print ( myString)
v <- 23.5
print(class(v))
v <- charToRaw("Hello")
print(class(v))

apple <- c('red','green',"yellow",12)
print(apple)
print(class(apple))

#list example 
list_test <- list(c(1,2,3),12,'apple')
print(list_test)
list_value <-list_test[1][2]
print(list_value)

print(View(data))
print(View(data$BMI))

test_n <- c(1,2,3,'azeem')
print(test_n)
print(class(test_n))

abc <- 1:9
print(abc)

new.squres <- function(a) {
  for(i in 1:a) {
    b <- i^2
    print(b)
  }
}
new.squres(5)

new.noArgument <- function(){
for(i in 1:20){
  b <-i^3
 print(b)
  }
}

new.noArgument()

a <- "azeem"
b <- "welcome"
 print (paste(a,b))
 