data <- read.csv("zxzX/diabetes.csv")

age <- c(25, 35, 50)
salary <- c(200000, 1200000, 2000000)
df <- data.frame( "Age" = age, "Salary" = salary, stringsAsFactors = FALSE)
df
normalize <- function(x){
  
  return ((x-min(x))/(max(x) - min(x)) )
}

df_norm <- as.data.frame(lapply(df, normalize))
print(paste("df_normr: ", df_norm))
df_norm


df_norm2 <- as.data.frame(lapply(df[1:1], normalize))
df_norm2

df_salry <- as.data.frame(lapply(df['Salary'], normalize))
df_salry

new_normalization <- function(x,new_max=1,new_min=0){
  # a=(((x- min(x)) * (new_max - new_min)) / max(x) -min(x)) + new_min
  # return (a)
  a= (((x-min(x))* (new_max-new_min))/(max(x)-min(x)))+new_min
  return(a)
}

fNorma1 <- as.data.frame(lapply(df[1:2], new_normalization))
fNorma1

dfNormZ <- as.data.frame( scale(df[1:2] ))
dfNormZ

#own zscore function

z_score = function(x) {
  return((x- mean(x))/sd(x))
}

df_norma4 <- as.data.frame(lapply(df, z_score))
df_norma4

